package com.example.spinwin;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    int coins=0; TextView coinText,result; Random random=new Random();
    int[] rewards={10,25,50,100,25,10,200,50};
    public void onCreate(Bundle b){super.onCreate(b); build();}
    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(24,32,24,24);
        TextView title=new TextView(this); title.setText("🎡 Spin & Win"); title.setTextSize(28); title.setGravity(17);
        root.addView(title,new LinearLayout.LayoutParams(-1,70));
        coinText=new TextView(this); coinText.setText("Coins: 0"); coinText.setTextSize(22); coinText.setGravity(17);
        root.addView(coinText,new LinearLayout.LayoutParams(-1,70));
        Button spin=new Button(this); spin.setText("SPIN NOW"); root.addView(spin,new LinearLayout.LayoutParams(-1,70));
        result=new TextView(this); result.setText("Tap Spin Now to play."); result.setTextSize(18); result.setGravity(17);
        root.addView(result,new LinearLayout.LayoutParams(-1,100));
        TextView note=new TextView(this); note.setText("AdMob test ads will be added in the next step."); note.setGravity(17);
        root.addView(note,new LinearLayout.LayoutParams(-1,80));
        spin.setOnClickListener(v->{int r=rewards[random.nextInt(rewards.length)]; coins+=r; coinText.setText("Coins: "+coins); result.setText("🎉 You won "+r+" coins!");});
        setContentView(root);
    }
}